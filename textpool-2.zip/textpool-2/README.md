# textpool

# Install the following:

Python 2.7

Node.js

# Python libraries using pip:

  nltk

  numpy

  scipy

  sklearn

  textblob

# Node.js modules using npm:

  express

  python-shell

